import pool from '../db.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';

const ensureString = (value, field) => {
  if (!value || typeof value !== 'string') {
    throw new HttpError(400, `${field}은(는) 문자열이어야 합니다.`);
  }
  const trimmed = value.trim();
  if (!trimmed) {
    throw new HttpError(400, `${field}을(를) 입력해주세요.`);
  }
  return trimmed;
};

export const signUp = asyncHandler(async (req, res) => {
  const name = ensureString(req.body.name, 'name');
  // gender는 0(여성) 또는 1(남성) 숫자로 받음
  const genderNum = Number(req.body.gender);
  if (genderNum !== 0 && genderNum !== 1) {
    throw new HttpError(400, 'gender는 0(여성) 또는 1(남성)이어야 합니다.');
  }
  const userId = ensureString(req.body.userId, 'userId');
  const password = ensureString(req.body.password, 'password');

  // 기본 온도 36도 (필요하면 body에서 temperature 받도록 확장 가능)
  const temperature = 36;

  // 아이디 중복 체크
  const [existing] = await pool.query(
    'SELECT id FROM users WHERE user_id = ?',
    [userId]
  );
  if (existing.length > 0) {
    throw new HttpError(409, '이미 존재하는 아이디입니다.');
  }

  await pool.execute(
    `INSERT INTO users (name, gender, user_id, password, temperature)
     VALUES (?, ?, ?, ?, ?)`,
    [name, genderNum, userId, password, temperature]
  );

  res.status(201).json({
    name,
    gender: genderNum, // 숫자로 반환
    userId,
    temperature,
  });
});

/**
 * 방 온도 평가 API
 * POST /api/users/rate
 * body: { roomId, rating, delta, currentTemperature? }
 */
export const rateUser = asyncHandler(async (req, res) => {
  console.log('평가 API 호출됨:', req.body);
  
  const roomId = req.body.roomId ? Number(req.body.roomId) : null;
  const rating = ensureString(req.body.rating, 'rating');
  const delta = Number(req.body.delta ?? 0);

  console.log('평가 데이터:', { roomId, rating, delta });

  if (rating !== 'good' && rating !== 'bad') {
    throw new HttpError(400, 'rating은 "good" 또는 "bad"여야 합니다.');
  }

  if (!roomId) {
    throw new HttpError(400, 'roomId가 필요합니다.');
  }

  // 방 존재 확인 및 현재 온도 조회
  console.log('방 조회:', roomId);
  const [rooms] = await pool.query(
    'SELECT id, temperature FROM rooms WHERE id = ?',
    [roomId]
  );

  console.log('조회된 방:', rooms);

  if (rooms.length === 0) {
    console.error('방을 찾을 수 없음:', roomId);
    throw new HttpError(404, `방을 찾을 수 없습니다. (room_id: ${roomId})`);
  }

  // temperature를 숫자로 변환 (DB에서 문자열로 올 수 있음)
  const rawTemp = rooms[0].temperature;
  const currentTemp = rawTemp != null ? Number(rawTemp) : 36.0;
  const safeCurrentTemp = isNaN(currentTemp) ? 36.0 : currentTemp;
  
  const newTemp = Math.max(0, Math.min(100, safeCurrentTemp + delta)); // 0~100 범위 제한

  console.log('방 온도 업데이트:', { 
    roomId, 
    rawTemperature: rawTemp,
    currentTemp: safeCurrentTemp, 
    delta, 
    newTemp 
  });

  // 방의 온도 업데이트
  const [updateResult] = await pool.execute(
    'UPDATE rooms SET temperature = ? WHERE id = ?',
    [newTemp, roomId]
  );

  console.log('업데이트 결과:', updateResult);
  console.log('영향받은 행 수:', updateResult.affectedRows);

  // 업데이트 확인
  const [updatedRooms] = await pool.query(
    'SELECT id, temperature FROM rooms WHERE id = ?',
    [roomId]
  );
  console.log('업데이트 후 방 정보:', updatedRooms);
  
  // 업데이트된 온도도 숫자로 변환
  const updatedTemp = updatedRooms[0]?.temperature != null 
    ? Number(updatedRooms[0].temperature) 
    : newTemp;
  const safeUpdatedTemp = isNaN(updatedTemp) ? newTemp : updatedTemp;

  res.status(200).json({
    roomId,
    previousTemperature: safeCurrentTemp,
    newTemperature: safeUpdatedTemp,
    delta,
    rating,
    affectedRows: updateResult.affectedRows,
  });
});


