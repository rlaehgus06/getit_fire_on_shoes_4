import pool from '../db.js';
import asyncHandler from '../utils/asyncHandler.js';
import HttpError from '../utils/httpError.js';

const ensureString = (value, field) => {
  if (!value || typeof value !== 'string') {
    throw new HttpError(400, `${field}은(는) 문자열이어야 합니다.`);
  }
  return value.trim();
};

const ensureDateTime = value => {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    throw new HttpError(400, 'departureTime은 ISO 날짜 문자열이어야 합니다.');
  }
  // MySQL DATETIME용 포맷 (초 단위까지만)
  return date.toISOString().slice(0, 19).replace('T', ' ');
};

const ensurePeople = value => {
  const num = Number(value ?? 4);
  if (!Number.isInteger(num) || num < 2 || num > 4) {
    throw new HttpError(400, 'maxPeople은 2~4 사이 정수여야 합니다.');
  }
  return num;
};

export const listRooms = asyncHandler(async (req, res) => {
  // 현재 유저의 성별 (쿼리 파라미터로 받음, 0: 여성, 1: 남성)
  // 성별 필터링은 일단 제거 - 모든 방 표시
  const userGender = req.query.gender ? Number(req.query.gender) : null;
  
  let query = `
    SELECT
      r.id,
      r.start,
      r.end,
      r.host_name      AS hostName,
      r.temperature    AS roomTemperature,
      r.departure_time AS departureTime,
      r.max_people     AS maxPeople,
      r.members,
      r.created_at     AS createdAt
    FROM rooms r
  `;
  
  // 성별 필터링 제거 - 모든 방 표시
  // 필요시 나중에 다시 추가 가능
  query += ` ORDER BY r.id DESC`;
  
  const [rows] = await pool.query(query);
  console.log('조회된 방 개수:', rows.length);
  res.status(200).json(rows);
});

export const createRoom = asyncHandler(async (req, res) => {
  console.log('방 생성 요청 받음:', req.body);
  
  const start = ensureString(req.body.start, 'start');
  const end = ensureString(req.body.end, 'end');
  const hostName = ensureString(req.body.hostName ?? '테스트', 'hostName');
  const departureTime = ensureDateTime(req.body.departureTime);
  const maxPeople = ensurePeople(req.body.maxPeople);

  console.log('방 생성 데이터:', { start, end, hostName, departureTime, maxPeople });

  try {
    // 방 생성 시 기본 온도 36.0 설정
    // temperature 컬럼이 없을 수 있으므로, 먼저 컬럼 존재 여부 확인 없이 시도
    // 만약 temperature 컬럼이 없으면 INSERT에서 제외
    const [result] = await pool.execute(
      `INSERT INTO rooms
        (start, end, host_name, departure_time, max_people, members)
       VALUES (?, ?, ?, ?, ?, 1)`,
      [start, end, hostName, departureTime, maxPeople]
    );

    console.log('방 생성 성공, ID:', result.insertId);

    // 생성된 방 정보 반환 (temperature는 있으면 포함, 없으면 null)
    const [rows] = await pool.query(
      `SELECT
         r.id,
         r.start,
         r.end,
         r.host_name      AS hostName,
         COALESCE(r.temperature, 36.0) AS roomTemperature,
         r.departure_time  AS departureTime,
         r.max_people      AS maxPeople,
         r.members,
         r.created_at      AS createdAt
       FROM rooms r
       WHERE r.id = ?`,
      [result.insertId]
    );

    console.log('생성된 방 정보:', rows[0]);
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('방 생성 DB 오류:', error);
    console.error('에러 메시지:', error.message);
    console.error('에러 코드:', error.code);
    throw error; // asyncHandler가 처리
  }
});
