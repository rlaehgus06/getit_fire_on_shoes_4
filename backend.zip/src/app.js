import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import router from './routes/index.js';
import { errorHandler } from './middlewares/errorHandler.js';



dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';

app.use(cors({
  origin: true,
  credentials: true,
  methods:["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders:["Content-Type", "Authorization"],
  optionsSuccessStatus:204
}));
app.use(express.json());

// API 라우터는 /api prefix로 마운트
app.use('/api', router);

app.get('/health', (req, res) => res.json({ ok: true, env: NODE_ENV }));

app.use(errorHandler);

app.listen(PORT, '0.0.0.0', () => {
  console.log(`API server running http://172.20.30.64:${PORT}`);
});
