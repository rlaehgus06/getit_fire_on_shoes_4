import { Router } from 'express';
import { createRoom, listRooms } from '../controllers/roomController.js';

const roomRouter = Router();

roomRouter.route('/')
  .get(listRooms)
  .post(createRoom);
  //.put(updateRoom)
  //.delete(deleteRoom);
  
export default roomRouter;

