import { Router } from 'express';
import itemRouter from './itemRouter.js';
import roomRouter from './roomRouter.js';
import authRouter from './authRouter.js';
import { rateUser } from '../controllers/authController.js';

const router = Router();

router.use('/items', itemRouter);
router.use('/rooms', roomRouter);
router.use('/auth', authRouter);
// POST /api/users/rate - 온도 평가 API
router.post('/users/rate', rateUser);

export default router;

