import { Router } from 'express';
import { signUp, rateUser } from '../controllers/authController.js';

const router = Router();

// POST /auth/signup
router.post('/signup', signUp);

export default router;


